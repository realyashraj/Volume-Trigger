# Volume Trigger (Android, Kotlin + Jetpack Compose)

Floating, draggable shortcut buttons that stay on top of other apps, plus a
Volume Up / Volume Down trigger. Source project for Android Studio.

> **NOT COMPILE-TESTED.** This project was written and reviewed by hand in an
> environment with no Android SDK, Gradle or internet. It has never been built
> or run on a device. Expect that Android Studio may report a small compile
> error or two on the first build.

## 1. Requirements
- Android Studio Koala (2024.1) or newer
- JDK 17 (bundled with Android Studio)
- Android SDK Platform 34 (Android Studio offers to install it)
- A phone on Android 8.0+ (API 26+), with USB debugging on, or an emulator

## 2. Open and build
1. Unzip `VolumeTrigger.zip`.
2. Android Studio > File > Open > select the `VolumeTrigger` folder.
3. Wait for Gradle sync (needs internet the first time).
4. **Gradle wrapper:** `gradlew` and `gradle-wrapper.jar` are NOT included
   (binary files that could not be downloaded here). Only
   `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.7) is included.
   Android Studio's own bundled Gradle handles sync. If sync complains, use
   Settings > Build Tools > Gradle > "Use Gradle from: local installation /
   default", or run `gradle wrapper --gradle-version 8.7` once in the folder.
5. Build APK: Build > Build App Bundle(s) / APK(s) > Build APK(s).
   Output: `app/build/outputs/apk/debug/app-debug.apk`.

## 3. Install
- Plug in phone and press Run, or copy `app-debug.apk` to the phone and open
  it (allow "install unknown apps" for your file manager/browser).
- Or: `adb install app/build/outputs/apk/debug/app-debug.apk`

## 4. Permissions and setup on the phone
1. **Display over other apps** (SYSTEM_ALERT_WINDOW): Home > Permissions &
   Setup > Grant Permission > turn on for Volume Trigger. Needed to draw the
   floating buttons.
2. **Accessibility Service**: Permissions & Setup > Open Accessibility
   Settings > Volume Trigger > turn on and accept the warning.
   It is used ONLY for (a) seeing Volume Up/Down key presses globally and
   (b) Home / Back / Recents / Notifications actions. It does not read screen
   content (`canRetrieveWindowContent=false`).
   Some phones (Xiaomi, Oppo, Vivo, Samsung, etc.) may switch it off after a
   restart or when battery-saving kills it - turn it on again and set the app
   to "No restrictions" / allow auto-start in battery settings.
3. Notifications: the foreground-service notification is exempt from the
   Android 13+ notification permission.
4. Home > Start Service. Add buttons under Floating Buttons. Set Volume Up /
   Down actions in Settings > Volume Button Trigger and switch on
   "Enable Volume Trigger".

Other manifest items: FOREGROUND_SERVICE(+_SPECIAL_USE), RECEIVE_BOOT_COMPLETED
(optional auto-start), `<queries>` for the "Open an app" picker. No
QUERY_ALL_PACKAGES, no root, no hidden APIs.

## 5. Known Android / OEM volume-key limitations
- Android has no normal-app API for global volume-key capture. The only
  supported way is an Accessibility Service, which is what this app uses.
- Many OEMs handle volume keys in the system before any app sees them,
  especially with the screen off/locked, on the lock screen, in some games,
  camera apps or during calls. Then Volume Trigger cannot react. This cannot
  be fixed by the app.
- Suppressing the normal volume change works only if the key event reaches the
  app; the OEM volume panel may still appear.
- Double press waits ~350 ms; long press fires at 500 ms.
- Overlay windows cannot appear over some secure screens (lock screen, some
  system dialogs, banking apps with secure windows).
- Accessibility services can be stopped by the OS/OEM; state is saved, so
  turning it back on restores everything.

## 6. Feature status (be aware)
Working (by code review, untested): service start/stop, foreground
notification with Hide/Show/Stop, draggable buttons with tap-vs-drag, saved
positions, master show/hide button, add/edit/duplicate/delete/enable buttons,
all listed actions, volume trigger (single/double/long), DataStore
persistence, onboarding, permissions screen, light/dark/system theme,
optional boot auto-start.

Saved as settings but NOT yet applied/implemented:
- Snap to edge, Animations, Haptic feedback toggles (stored, no effect yet)
- Default button size/transparency (used as defaults in the Add screen only;
  no controls in Settings)
- Long-press "edit/move mode" outline, trigger sensitivity, accent color,
  global button-shape setting, Master Button Position setting (drag it
  instead), button reordering UI (repository function exists)
- Transparency slider minimum is 20% so buttons can't become invisible
- No loop protection: two buttons set to "run each other" will loop forever
- Only 11 simple built-in icons
- Not tested: rotation, process death, reboot, OEM behaviour

## 7. Compile-risk notes
- `Modifier.menuAnchor()` (no arguments) matches Compose BOM 2024.06.00. If
  you upgrade Material3 to 1.3+, switch to `menuAnchor(MenuAnchorType...)`.
- Versions used: AGP 8.5.0, Kotlin 1.9.24, Compose compiler 1.5.14,
  compileSdk/targetSdk 34, minSdk 26.
