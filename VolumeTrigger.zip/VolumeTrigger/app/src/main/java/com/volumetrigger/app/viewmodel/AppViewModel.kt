package com.volumetrigger.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.volumetrigger.app.data.ButtonRepository
import com.volumetrigger.app.data.SettingsRepository
import com.volumetrigger.app.data.model.AppSettings
import com.volumetrigger.app.data.model.ButtonAction
import com.volumetrigger.app.data.model.ButtonShape
import com.volumetrigger.app.data.model.FloatingButtonConfig
import com.volumetrigger.app.service.OverlayService
import com.volumetrigger.app.service.VolumeAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val buttonRepository = ButtonRepository(application)
    private val settingsRepository = SettingsRepository(application)

    // DataStore reads are asynchronous, so `settings` starts at this default
    // (onboardingComplete = false) for a brief moment even for a returning
    // user. MainActivity uses this flag to hold off building the nav graph
    // until the real value has actually loaded, so it doesn't briefly pick
    // "onboarding" as the start destination and then have to rebuild itself.
    private val _settingsLoaded = MutableStateFlow(false)
    val settingsLoaded: StateFlow<Boolean> = _settingsLoaded

    val settings: StateFlow<AppSettings> = settingsRepository.settingsFlow
        .onEach { _settingsLoaded.value = true }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val buttons: StateFlow<List<FloatingButtonConfig>> = buttonRepository.buttonsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // True once the service has actually started drawing (foreground service alive).
    val serviceRunning: StateFlow<Boolean> = OverlayService.isRunning
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val accessibilityRunning: StateFlow<Boolean> = VolumeAccessibilityService.isRunning
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    fun startService() = OverlayService.ensureStarted(getApplication())
    fun stopService() = OverlayService.stop(getApplication())

    fun findButton(id: String): FloatingButtonConfig? = buttons.value.firstOrNull { it.id == id }

    fun addButton(
        name: String,
        icon: String,
        action: ButtonAction,
        sizeDp: Int,
        alphaPercent: Int,
        shape: ButtonShape,
        showLabel: Boolean
    ) {
        viewModelScope.launch {
            buttonRepository.addButton(
                FloatingButtonConfig(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    icon = icon,
                    action = action,
                    sizeDp = sizeDp,
                    alphaPercent = alphaPercent,
                    shape = shape,
                    showLabel = showLabel
                )
            )
        }
    }

    fun updateButton(config: FloatingButtonConfig) {
        viewModelScope.launch { buttonRepository.updateButton(config) }
    }

    fun deleteButton(id: String) {
        viewModelScope.launch { buttonRepository.deleteButton(id) }
    }

    fun setButtonEnabled(id: String, enabled: Boolean) {
        viewModelScope.launch { buttonRepository.setEnabled(id, enabled) }
    }

    fun duplicateButton(id: String) {
        val source = findButton(id) ?: return
        viewModelScope.launch {
            buttonRepository.addButton(
                source.copy(id = UUID.randomUUID().toString(), name = "${source.name} copy")
            )
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepository.update(transform) }
    }
}
