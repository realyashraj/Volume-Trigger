package com.volumetrigger.app.overlay

import com.volumetrigger.app.R

/**
 * Maps a small icon key (stored in FloatingButtonConfig.icon) to a drawable
 * resource. This is a starter set; add more vector drawables under res/drawable
 * and register them here to expand the icon picker.
 */
object IconCatalog {

    private val map: Map<String, Int> = mapOf(
        "circle" to R.drawable.ic_circle,
        "home" to R.drawable.ic_home,
        "back" to R.drawable.ic_back,
        "recents" to R.drawable.ic_recents,
        "notifications" to R.drawable.ic_notifications,
        "wifi" to R.drawable.ic_wifi,
        "bluetooth" to R.drawable.ic_bluetooth,
        "settings" to R.drawable.ic_settings_gear,
        "apps" to R.drawable.ic_apps,
        "toggle" to R.drawable.ic_toggle,
        "link" to R.drawable.ic_link
    )

    val allKeys: List<String> = map.keys.toList()

    fun resolve(key: String): Int = map[key] ?: R.drawable.ic_circle
}
