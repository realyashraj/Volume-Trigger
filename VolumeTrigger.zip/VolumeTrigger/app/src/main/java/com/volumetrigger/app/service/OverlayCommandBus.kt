package com.volumetrigger.app.service

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

sealed class OverlayCommand {
    object ShowAll : OverlayCommand()
    object HideAll : OverlayCommand()
    object ToggleAll : OverlayCommand()
    data class Execute(val buttonId: String) : OverlayCommand()
}

/**
 * In-process event bus connecting VolumeAccessibilityService (which detects
 * the key press) to OverlayService (which owns the WindowManager views).
 * Both services run in the app's default process, so a simple shared flow
 * is enough - no cross-process IPC is needed.
 */
object OverlayCommandBus {
    private val _commands = MutableSharedFlow<OverlayCommand>(extraBufferCapacity = 8)
    val commands = _commands.asSharedFlow()
    fun send(command: OverlayCommand) {
        _commands.tryEmit(command)
    }
}
