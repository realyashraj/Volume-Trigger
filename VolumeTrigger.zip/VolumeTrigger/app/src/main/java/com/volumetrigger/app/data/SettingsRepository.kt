package com.volumetrigger.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.volumetrigger.app.data.model.AppSettings
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.settingsDataStore by preferencesDataStore(name = "vt_settings")

/**
 * Persists the single AppSettings object as JSON in DataStore Preferences.
 * DataStore is used (rather than SharedPreferences) because it is the
 * officially recommended, crash-safe, coroutine-first persistence API.
 */
class SettingsRepository(private val context: Context) {

    private val key = stringPreferencesKey("app_settings_json")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val settingsFlow = context.settingsDataStore.data.map { prefs ->
        prefs[key]?.let { raw -> runCatching { json.decodeFromString<AppSettings>(raw) }.getOrNull() }
            ?: AppSettings()
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { prefs ->
            val current = prefs[key]
                ?.let { runCatching { json.decodeFromString<AppSettings>(it) }.getOrNull() }
                ?: AppSettings()
            prefs[key] = json.encodeToString(transform(current))
        }
    }

    suspend fun updateMasterPosition(x: Float, y: Float) {
        update { it.copy(masterButtonX = x, masterButtonY = y) }
    }
}
