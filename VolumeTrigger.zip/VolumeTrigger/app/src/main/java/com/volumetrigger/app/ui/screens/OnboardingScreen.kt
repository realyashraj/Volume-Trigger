package com.volumetrigger.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.volumetrigger.app.util.PermissionChecker
import com.volumetrigger.app.viewmodel.AppViewModel

private data class Step(val title: String, val body: String)

private val steps = listOf(
    Step("Welcome to Volume Trigger", "Create floating shortcuts you can trigger with your Volume Up / Down buttons, then drag them anywhere on screen."),
    Step("Allow Display Over Other Apps", "This lets your floating buttons stay visible while you use other apps. You can grant it now or later from Permissions & Setup."),
    Step("Configure Volume Buttons", "Decide what Volume Up and Volume Down do from the Settings tab - for example, toggling your floating buttons on and off."),
    Step("Create Your First Floating Button", "Add a button, pick an icon and an action, then drag it wherever it's easiest to reach."),
    Step("You're Ready", "Start the service from the Home screen whenever you want your shortcuts on screen.")
)

@Composable
fun OnboardingScreen(viewModel: AppViewModel, onFinish: () -> Unit) {
    var stepIndex by remember { mutableStateOf(0) }
    val context = LocalContext.current
    val step = steps[stepIndex]

    Scaffold { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(1f))
            Text(step.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text(step.body, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)

            if (stepIndex == 1) {
                Spacer(Modifier.height(20.dp))
                OutlinedButton(onClick = { context.startActivity(PermissionChecker.overlaySettingsIntent(context)) }) {
                    Text("Open overlay permission settings")
                }
            }

            Spacer(Modifier.weight(1f))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                steps.indices.forEach { i ->
                    Box(
                        Modifier
                            .weight(1f)
                            .height(4.dp)
                            .background(
                                if (i <= stepIndex) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(2.dp)
                            )
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    if (stepIndex == steps.lastIndex) onFinish() else stepIndex++
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(if (stepIndex == steps.lastIndex) "Finish Setup" else "Next")
            }

            if (stepIndex < steps.lastIndex) {
                TextButton(onClick = onFinish, modifier = Modifier.padding(top = 8.dp)) {
                    Text("Skip")
                }
            }
        }
    }
}
