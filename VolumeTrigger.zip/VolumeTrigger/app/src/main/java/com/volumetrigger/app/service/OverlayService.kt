package com.volumetrigger.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.volumetrigger.app.MainActivity
import com.volumetrigger.app.R
import com.volumetrigger.app.data.ButtonRepository
import com.volumetrigger.app.data.SettingsRepository
import com.volumetrigger.app.data.model.FloatingButtonConfig
import com.volumetrigger.app.overlay.FloatingButtonView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Foreground service that owns every floating WindowManager overlay window:
 * one per configured button, plus the master show/hide button. It reacts
 * live to DataStore changes (buttons added/edited/removed/moved) and to
 * OverlayCommand events sent from the accessibility service or from a
 * button's own tap.
 */
class OverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "volume_trigger_service"
        const val NOTIF_ID = 42
        const val ACTION_STOP = "com.volumetrigger.app.action.STOP"
        const val ACTION_SHOW = "com.volumetrigger.app.action.SHOW"
        const val ACTION_HIDE = "com.volumetrigger.app.action.HIDE"
        private const val MASTER_ID = "__master__"

        val isRunning = MutableStateFlow(false)

        fun ensureStarted(context: Context) {
            val intent = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var windowManager: WindowManager
    private lateinit var buttonRepository: ButtonRepository
    private lateinit var settingsRepository: SettingsRepository

    private val activeViews = mutableMapOf<String, FloatingButtonView>()
    private var masterView: FloatingButtonView? = null
    private var masterButtonRequested = false
    private var buttonsVisible = true

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buttonRepository = ButtonRepository(applicationContext)
        settingsRepository = SettingsRepository(applicationContext)

        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        isRunning.value = true

        scope.launch { buttonRepository.buttonsFlow.collectLatest { syncButtons(it) } }
        scope.launch { OverlayCommandBus.commands.collect { handle(it) } }
        scope.launch {
            settingsRepository.settingsFlow.collectLatest { settings ->
                masterView?.setHidden(settings.masterButtonHidden)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SHOW -> handle(OverlayCommand.ShowAll)
            ACTION_HIDE -> handle(OverlayCommand.HideAll)
        }
        return START_STICKY
    }

    private fun handle(command: OverlayCommand) {
        when (command) {
            OverlayCommand.ShowAll -> { buttonsVisible = true; applyVisibility() }
            OverlayCommand.HideAll -> { buttonsVisible = false; applyVisibility() }
            OverlayCommand.ToggleAll -> { buttonsVisible = !buttonsVisible; applyVisibility() }
            is OverlayCommand.Execute -> {
                activeViews[command.buttonId]?.config?.action?.let {
                    ActionExecutor.execute(this, it)
                }
            }
        }
        updateNotification()
    }

    private fun applyVisibility() {
        activeViews.values.forEach { it.visibility = if (buttonsVisible) View.VISIBLE else View.GONE }
    }

    private fun syncButtons(configs: List<FloatingButtonConfig>) {
        val incomingIds = configs.map { it.id }.toSet()
        (activeViews.keys - incomingIds).forEach { id ->
            activeViews[id]?.let { runCatching { windowManager.removeView(it) } }
            activeViews.remove(id)
        }
        configs.forEach { config ->
            val existing = activeViews[config.id]
            when {
                existing == null && config.enabled -> addButtonView(config)
                existing != null && !config.enabled -> {
                    runCatching { windowManager.removeView(existing) }
                    activeViews.remove(config.id)
                }
                existing != null -> existing.updateConfig(config)
            }
        }
        ensureMasterButton()
    }

    private fun addButtonView(config: FloatingButtonConfig) {
        val view = FloatingButtonView(this, config) { id, x, y ->
            scope.launch { buttonRepository.updateButtonPosition(id, x, y) }
        }
        view.onClick = { OverlayCommandBus.send(OverlayCommand.Execute(config.id)) }
        val params = layoutParamsFor(config.x, config.y)
        runCatching {
            windowManager.addView(view, params)
            view.windowParams = params
            view.visibility = if (buttonsVisible) View.VISIBLE else View.GONE
            activeViews[config.id] = view
        }
    }

    private fun ensureMasterButton() {
        // syncButtons() runs synchronously on the main dispatcher every time
        // buttonsFlow emits, but reading settings below is a suspend call.
        // Without this flag, two emissions arriving close together (e.g. at
        // cold start, before masterView is set) would both pass the
        // "masterView != null" check and each add a master button window.
        if (masterView != null || masterButtonRequested) return
        masterButtonRequested = true
        scope.launch {
            val settings = settingsRepository.settingsFlow.first()
            val masterConfig = FloatingButtonConfig(
                id = MASTER_ID,
                name = "Show/Hide",
                icon = "toggle",
                x = settings.masterButtonX,
                y = settings.masterButtonY
            )
            val view = FloatingButtonView(this@OverlayService, masterConfig, isMaster = true) { _, x, y ->
                scope.launch { settingsRepository.updateMasterPosition(x, y) }
            }
            view.onClick = { OverlayCommandBus.send(OverlayCommand.ToggleAll) }
            val params = layoutParamsFor(masterConfig.x, masterConfig.y)
            val added = runCatching {
                windowManager.addView(view, params)
                view.windowParams = params
                view.setHidden(settings.masterButtonHidden)
                masterView = view
            }
            if (added.isFailure) {
                // Most likely cause: overlay permission isn't actually granted
                // yet. Allow a later buttons/settings emission to retry.
                masterButtonRequested = false
            }
        }
    }

    private fun layoutParamsFor(x: Float, y: Float): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x.toInt()
            this.y = y.toInt()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Volume Trigger service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val toggleAction = if (buttonsVisible) {
            NotificationCompat.Action(0, "Hide buttons", pendingServiceIntent(ACTION_HIDE))
        } else {
            NotificationCompat.Action(0, "Show buttons", pendingServiceIntent(ACTION_SHOW))
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Volume Trigger is active")
            .setContentText(if (buttonsVisible) "Floating buttons visible" else "Floating buttons hidden")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .addAction(toggleAction)
            .addAction(NotificationCompat.Action(0, "Stop service", pendingServiceIntent(ACTION_STOP)))
            .build()
    }

    private fun pendingServiceIntent(action: String): PendingIntent {
        val intent = Intent(this, OverlayService::class.java).setAction(action)
        return PendingIntent.getService(this, action.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE)
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        activeViews.values.forEach { runCatching { windowManager.removeView(it) } }
        masterView?.let { runCatching { windowManager.removeView(it) } }
        activeViews.clear()
        masterView = null
        isRunning.value = false
        scope.cancel()
    }
}
