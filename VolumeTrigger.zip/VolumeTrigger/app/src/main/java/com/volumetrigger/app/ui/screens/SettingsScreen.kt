package com.volumetrigger.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.volumetrigger.app.data.model.PressType
import com.volumetrigger.app.data.model.ThemeMode
import com.volumetrigger.app.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: AppViewModel, onBack: () -> Unit) {
    val settings by viewModel.settings.collectAsState()
    val buttons by viewModel.buttons.collectAsState()
    var resetConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp)) {

            SectionCard("Volume Button Trigger") {
                SettingsSwitchRow(
                    "Enable Volume Trigger",
                    checked = settings.volumeTriggerEnabled,
                    onCheckedChange = { on -> viewModel.updateSettings { it.copy(volumeTriggerEnabled = on) } }
                )
                Spacer(Modifier.height(8.dp))
                ActionPicker("Volume Up action", settings.volumeUpAction, buttons) { action ->
                    viewModel.updateSettings { it.copy(volumeUpAction = action) }
                }
                Spacer(Modifier.height(12.dp))
                ActionPicker("Volume Down action", settings.volumeDownAction, buttons) { action ->
                    viewModel.updateSettings { it.copy(volumeDownAction = action) }
                }
                Spacer(Modifier.height(16.dp))
                Text("Press type", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                SingleChoiceRow(
                    options = listOf(PressType.SINGLE to "Single", PressType.DOUBLE to "Double", PressType.LONG to "Long"),
                    selected = settings.pressType,
                    onSelected = { pt -> viewModel.updateSettings { it.copy(pressType = pt) } }
                )
                Spacer(Modifier.height(8.dp))
                SettingsSwitchRow(
                    "Suppress normal volume change",
                    subtitle = "Only when an action is assigned. Android may still show its own volume UI on some devices.",
                    checked = settings.suppressVolumeChange,
                    onCheckedChange = { v -> viewModel.updateSettings { it.copy(suppressVolumeChange = v) } }
                )
            }

            SectionCard("Floating Buttons") {
                SettingsSwitchRow(
                    "Snap to edge",
                    checked = settings.snapToEdge,
                    onCheckedChange = { v -> viewModel.updateSettings { it.copy(snapToEdge = v) } }
                )
                SettingsSwitchRow(
                    "Animations",
                    checked = settings.animationsEnabled,
                    onCheckedChange = { v -> viewModel.updateSettings { it.copy(animationsEnabled = v) } }
                )
                SettingsSwitchRow(
                    "Show button labels",
                    checked = settings.showLabels,
                    onCheckedChange = { v -> viewModel.updateSettings { it.copy(showLabels = v) } }
                )
                SettingsSwitchRow(
                    "Haptic feedback",
                    checked = settings.hapticFeedback,
                    onCheckedChange = { v -> viewModel.updateSettings { it.copy(hapticFeedback = v) } }
                )
                SettingsSwitchRow(
                    "Master button hidden",
                    subtitle = "Hides the master show/hide button too. Reopen the app to bring it back.",
                    checked = settings.masterButtonHidden,
                    onCheckedChange = { v -> viewModel.updateSettings { it.copy(masterButtonHidden = v) } }
                )
            }

            SectionCard("Appearance") {
                Text("Theme", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                SingleChoiceRow(
                    options = listOf(ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark", ThemeMode.SYSTEM to "System"),
                    selected = settings.themeMode,
                    onSelected = { m -> viewModel.updateSettings { it.copy(themeMode = m) } }
                )
            }

            SectionCard("Behavior") {
                SettingsSwitchRow(
                    "Start service automatically",
                    subtitle = "Restores floating buttons after the app process starts, where Android permits.",
                    checked = settings.autoStartService,
                    onCheckedChange = { v -> viewModel.updateSettings { it.copy(autoStartService = v) } }
                )
                SettingsSwitchRow(
                    "Confirm before deleting a button",
                    checked = settings.confirmBeforeDelete,
                    onCheckedChange = { v -> viewModel.updateSettings { it.copy(confirmBeforeDelete = v) } }
                )
            }

            SectionCard("Safety") {
                OutlinedButton(onClick = { resetConfirm = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Reset all settings")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { viewModel.stopService() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Stop service")
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    if (resetConfirm) {
        AlertDialog(
            onDismissRequest = { resetConfirm = false },
            title = { Text("Reset all settings?") },
            text = { Text("This resets Volume Trigger, appearance, and behavior settings to their defaults. Your floating buttons are not deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    resetConfirm = false
                    viewModel.updateSettings { com.volumetrigger.app.data.model.AppSettings(onboardingComplete = true) }
                }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { resetConfirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun <T> SingleChoiceRow(options: List<Pair<T, String>>, selected: T, onSelected: (T) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, text) ->
            FilterChip(selected = value == selected, onClick = { onSelected(value) }, label = { Text(text) })
        }
    }
}
