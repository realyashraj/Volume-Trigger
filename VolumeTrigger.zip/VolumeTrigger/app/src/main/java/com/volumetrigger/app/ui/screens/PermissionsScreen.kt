package com.volumetrigger.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.volumetrigger.app.util.PermissionChecker
import com.volumetrigger.app.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsScreen(viewModel: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    var overlayGranted by remember { mutableStateOf(PermissionChecker.hasOverlayPermission(context)) }
    var accessibilityGranted by remember { mutableStateOf(PermissionChecker.isAccessibilityServiceEnabled(context)) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                overlayGranted = PermissionChecker.hasOverlayPermission(context)
                accessibilityGranted = PermissionChecker.isAccessibilityServiceEnabled(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Permissions & Setup") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp)
        ) {
            SectionCard("Display over other apps") {
                Text(
                    "Required so floating buttons can be drawn on top of other apps.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                StatusRow("Status", overlayGranted)
                Spacer(Modifier.height(10.dp))
                if (!overlayGranted) {
                    Button(
                        onClick = { context.startActivity(PermissionChecker.overlaySettingsIntent(context)) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("Grant Permission") }
                }
            }

            SectionCard("Accessibility Service") {
                Text(
                    "Needed only for two things: detecting Volume Up/Down presses globally, " +
                        "and running Home / Back / Recents / Notifications actions on a button tap. " +
                        "Android does not expose either of these to a normal app any other way. " +
                        "No screen content is read.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                StatusRow("Status", accessibilityGranted)
                Spacer(Modifier.height(10.dp))
                if (!accessibilityGranted) {
                    Button(
                        onClick = { context.startActivity(PermissionChecker.accessibilitySettingsIntent()) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("Open Accessibility Settings") }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Find \"Volume Trigger\" in the list and turn it on.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SectionCard("Known Android limitation") {
                Text(
                    "Some device makers still intercept the volume keys for their own volume UI " +
                        "before any app can see them, even with this permission on. If Volume Trigger " +
                        "doesn't respond on your device, that restriction is coming from the OS/OEM, " +
                        "not from a missing setting here.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
