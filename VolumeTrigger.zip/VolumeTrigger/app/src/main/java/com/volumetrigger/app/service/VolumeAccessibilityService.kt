package com.volumetrigger.app.service

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.volumetrigger.app.data.SettingsRepository
import com.volumetrigger.app.data.model.AppSettings
import com.volumetrigger.app.data.model.ButtonAction
import com.volumetrigger.app.data.model.PressType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * IMPORTANT ANDROID LIMITATION (see README "Known limitations"):
 * There is no public Android API for a normal app to globally intercept
 * hardware volume key presses while another app is in the foreground.
 * The only officially supported mechanism is an AccessibilityService with
 * canRequestFilterKeyEvents="true" (declared in accessibility_service_config.xml).
 * That is what this service does - nothing here uses root, hidden APIs, or
 * an unsupported hack. On some OEM skins the system may still consume the
 * key first for its own volume UI; when that happens this app cannot see it,
 * and there's no supported way around that either.
 */
class VolumeAccessibilityService : AccessibilityService() {

    companion object {
        /** Non-null only while the service is actually connected & enabled. */
        var runningInstance: VolumeAccessibilityService? = null
            private set

        val isRunning = MutableStateFlow(false)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var settingsRepository: SettingsRepository
    @Volatile private var cachedSettings: AppSettings = AppSettings()

    private var longPressJob: Job? = null
    private var lastUpTapTime = 0L
    private var lastDownTapTime = 0L
    private val doublePressWindowMs = 350L
    private val longPressDelayMs = 500L

    override fun onServiceConnected() {
        super.onServiceConnected()
        runningInstance = this
        isRunning.value = true
        settingsRepository = SettingsRepository(applicationContext)
        scope.launch {
            settingsRepository.settingsFlow.collectLatest { cachedSettings = it }
        }
        // Make sure the overlay (floating buttons) is drawn whenever this
        // service is alive, since the user has clearly granted accessibility.
        OverlayService.ensureStarted(applicationContext)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val settings = cachedSettings
        if (!settings.volumeTriggerEnabled) return false

        val isVolumeKey = event.keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (!isVolumeKey) return false
        val isUp = event.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        val assignedAction = if (isUp) settings.volumeUpAction else settings.volumeDownAction

        when (event.action) {
            KeyEvent.ACTION_DOWN -> onKeyDown(isUp, settings.pressType)
            KeyEvent.ACTION_UP -> onKeyUp(isUp, settings.pressType)
        }

        // Only swallow the key (and so suppress the system volume UI/sound)
        // when an action is actually assigned and the user opted into that.
        return settings.suppressVolumeChange && assignedAction != ButtonAction.None
    }

    private fun onKeyDown(isUp: Boolean, pressType: PressType) {
        if (pressType != PressType.LONG) return
        longPressJob?.cancel()
        longPressJob = scope.launch {
            kotlinx.coroutines.delay(longPressDelayMs)
            dispatch(isUp)
        }
    }

    private fun onKeyUp(isUp: Boolean, pressType: PressType) {
        when (pressType) {
            PressType.SINGLE -> dispatch(isUp)
            PressType.LONG -> longPressJob?.cancel() // released before the delay = short press, ignored
            PressType.DOUBLE -> handleDoublePress(isUp)
        }
    }

    private fun handleDoublePress(isUp: Boolean) {
        val now = System.currentTimeMillis()
        if (isUp) {
            if (now - lastUpTapTime < doublePressWindowMs) {
                dispatch(true)
                lastUpTapTime = 0L
            } else {
                lastUpTapTime = now
            }
        } else {
            if (now - lastDownTapTime < doublePressWindowMs) {
                dispatch(false)
                lastDownTapTime = 0L
            } else {
                lastDownTapTime = now
            }
        }
    }

    private fun dispatch(isUp: Boolean) {
        val action = if (isUp) cachedSettings.volumeUpAction else cachedSettings.volumeDownAction
        ActionExecutor.execute(applicationContext, action)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // This service intentionally does not read window/content events.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        runningInstance = null
        isRunning.value = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        runningInstance = null
        isRunning.value = false
        scope.cancel()
    }
}
