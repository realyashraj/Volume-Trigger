package com.volumetrigger.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.volumetrigger.app.data.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Optional: only takes effect if the user turned on "Start service
 * automatically" in Settings. Button positions/config already survive
 * reboot on their own since they're in DataStore, not memory - this
 * receiver only decides whether to relaunch the overlay without the user
 * having to open the app first.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val settings = SettingsRepository(context.applicationContext).settingsFlow.first()
                if (settings.autoStartService) {
                    OverlayService.ensureStarted(context.applicationContext)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
