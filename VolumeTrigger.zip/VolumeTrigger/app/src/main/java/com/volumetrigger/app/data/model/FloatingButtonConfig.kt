package com.volumetrigger.app.data.model

import kotlinx.serialization.Serializable

enum class ButtonShape { CIRCLE, ROUNDED_SQUARE }

@Serializable
sealed class ButtonAction {
    @Serializable object None : ButtonAction()
    @Serializable object GoHome : ButtonAction()
    @Serializable object Back : ButtonAction()
    @Serializable object RecentApps : ButtonAction()
    @Serializable object Notifications : ButtonAction()
    @Serializable object ToggleFloatingButtons : ButtonAction()
    @Serializable object ShowFloatingButtons : ButtonAction()
    @Serializable object HideFloatingButtons : ButtonAction()
    @Serializable object OpenWifiSettings : ButtonAction()
    @Serializable object OpenBluetoothSettings : ButtonAction()
    @Serializable object OpenAppSettings : ButtonAction()
    @Serializable data class OpenApp(val packageName: String, val appLabel: String = "") : ButtonAction()
    @Serializable data class OpenUrl(val url: String) : ButtonAction()
    @Serializable data class ExecuteButton(val buttonId: String) : ButtonAction()

    /** Short label used in dropdowns and the buttons list. */
    fun displayName(): String = when (this) {
        is None -> "No action"
        is GoHome -> "Go Home"
        is Back -> "Back"
        is RecentApps -> "Recent Apps"
        is Notifications -> "Show Notifications"
        is ToggleFloatingButtons -> "Toggle Floating Buttons"
        is ShowFloatingButtons -> "Show Floating Buttons"
        is HideFloatingButtons -> "Hide Floating Buttons"
        is OpenWifiSettings -> "Open Wi-Fi Settings"
        is OpenBluetoothSettings -> "Open Bluetooth Settings"
        is OpenAppSettings -> "Open Settings"
        is OpenApp -> "Open ${appLabel.ifBlank { packageName }}"
        is OpenUrl -> "Open $url"
        is ExecuteButton -> "Run another button"
    }
}

@Serializable
data class FloatingButtonConfig(
    val id: String,
    val name: String,
    val icon: String = "circle",
    val action: ButtonAction = ButtonAction.None,
    val x: Float = 60f,
    val y: Float = 400f,
    val sizeDp: Int = 56,
    val alphaPercent: Int = 100,
    val shape: ButtonShape = ButtonShape.CIRCLE,
    val showLabel: Boolean = false,
    val enabled: Boolean = true
)
