package com.volumetrigger.app.ui.navigation

object AppDestinations {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val BUTTONS = "buttons"
    const val ADD_EDIT_BUTTON = "add_edit_button/{id}"
    const val SETTINGS = "settings"
    const val PERMISSIONS = "permissions"

    fun addEditButtonRoute(id: String? = null) = "add_edit_button/${id ?: "new"}"
}
