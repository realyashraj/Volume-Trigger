package com.volumetrigger.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.volumetrigger.app.data.model.ButtonAction
import com.volumetrigger.app.data.model.ButtonShape
import com.volumetrigger.app.data.model.FloatingButtonConfig
import com.volumetrigger.app.overlay.IconCatalog
import com.volumetrigger.app.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditButtonScreen(viewModel: AppViewModel, buttonId: String?, onDone: () -> Unit) {
    val settings by viewModel.settings.collectAsState()
    val allButtons by viewModel.buttons.collectAsState()
    val existing = remember(buttonId, allButtons) { buttonId?.let { id -> allButtons.firstOrNull { it.id == id } } }
    val isEditing = existing != null

    var name by remember { mutableStateOf(existing?.name ?: "") }
    var icon by remember { mutableStateOf(existing?.icon ?: "circle") }
    var action by remember { mutableStateOf<ButtonAction>(existing?.action ?: ButtonAction.None) }
    var sizeDp by remember { mutableStateOf((existing?.sizeDp ?: settings.defaultButtonSizeDp).toFloat()) }
    var alphaPercent by remember { mutableStateOf((existing?.alphaPercent ?: settings.defaultAlphaPercent).toFloat()) }
    var shape by remember { mutableStateOf(existing?.shape ?: ButtonShape.CIRCLE) }
    var showLabel by remember { mutableStateOf(existing?.showLabel ?: settings.showLabels) }

    val otherButtons = allButtons.filter { it.id != buttonId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Edit Floating Button" else "Add Floating Button") },
                navigationIcon = {
                    IconButton(onClick = onDone) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp)) {

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Button Name") },
                placeholder = { Text("Quick Action") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))
            Text("Icon", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(IconCatalog.allKeys) { key ->
                    val selected = key == icon
                    Box(
                        Modifier
                            .size(48.dp)
                            .background(Color(0xFF3B82F6), CircleShape)
                            .border(
                                width = if (selected) 3.dp else 0.dp,
                                color = MaterialTheme.colorScheme.primary,
                                shape = CircleShape
                            )
                            .clickable { icon = key },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(IconCatalog.resolve(key)),
                            contentDescription = key,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Button Size: ${sizeDp.toInt()}dp", style = MaterialTheme.typography.labelLarge)
            Slider(value = sizeDp, onValueChange = { sizeDp = it }, valueRange = 40f..96f, steps = 13)

            Spacer(Modifier.height(12.dp))
            Text("Transparency: ${alphaPercent.toInt()}%", style = MaterialTheme.typography.labelLarge)
            Slider(value = alphaPercent, onValueChange = { alphaPercent = it }, valueRange = 20f..100f)

            Spacer(Modifier.height(12.dp))
            Text("Shape", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = shape == ButtonShape.CIRCLE, onClick = { shape = ButtonShape.CIRCLE }, label = { Text("Circle") })
                FilterChip(selected = shape == ButtonShape.ROUNDED_SQUARE, onClick = { shape = ButtonShape.ROUNDED_SQUARE }, label = { Text("Rounded square") })
            }

            Spacer(Modifier.height(12.dp))
            SettingsSwitchRow("Show label under button", checked = showLabel, onCheckedChange = { showLabel = it })

            Spacer(Modifier.height(20.dp))
            ActionPicker("Action", action, otherButtons) { action = it }

            Spacer(Modifier.height(28.dp))
            Button(
                onClick = {
                    if (name.isBlank()) return@Button
                    if (isEditing && existing != null) {
                        viewModel.updateButton(
                            existing.copy(
                                name = name.trim(),
                                icon = icon,
                                action = action,
                                sizeDp = sizeDp.toInt(),
                                alphaPercent = alphaPercent.toInt(),
                                shape = shape,
                                showLabel = showLabel
                            )
                        )
                    } else {
                        viewModel.addButton(
                            name = name.trim(),
                            icon = icon,
                            action = action,
                            sizeDp = sizeDp.toInt(),
                            alphaPercent = alphaPercent.toInt(),
                            shape = shape,
                            showLabel = showLabel
                        )
                    }
                    onDone()
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(if (isEditing) "Save Changes" else "Create Button")
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
