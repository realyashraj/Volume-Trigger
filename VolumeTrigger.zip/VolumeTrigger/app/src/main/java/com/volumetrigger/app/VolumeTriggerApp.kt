package com.volumetrigger.app

import android.app.Application
import com.volumetrigger.app.data.SettingsRepository
import com.volumetrigger.app.service.OverlayService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class VolumeTriggerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Covers the app process being created for any reason (opening the
        // app, or the BootReceiver waking it up) when "start service
        // automatically" is on. A one-shot read, not an ongoing collector.
        CoroutineScope(Dispatchers.Default).launch {
            val settings = SettingsRepository(applicationContext).settingsFlow.first()
            if (settings.autoStartService) {
                OverlayService.ensureStarted(applicationContext)
            }
        }
    }
}
