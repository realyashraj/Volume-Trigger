package com.volumetrigger.app.data.model

import kotlinx.serialization.Serializable

enum class PressType { SINGLE, DOUBLE, LONG }
enum class ThemeMode { LIGHT, DARK, SYSTEM }

@Serializable
data class AppSettings(
    // Volume trigger
    val volumeTriggerEnabled: Boolean = false,
    val volumeUpAction: ButtonAction = ButtonAction.None,
    val volumeDownAction: ButtonAction = ButtonAction.None,
    val pressType: PressType = PressType.SINGLE,
    val suppressVolumeChange: Boolean = true,

    // Floating button defaults
    val defaultButtonSizeDp: Int = 56,
    val defaultAlphaPercent: Int = 100,
    val snapToEdge: Boolean = true,
    val animationsEnabled: Boolean = true,
    val showLabels: Boolean = false,
    val hapticFeedback: Boolean = true,

    // Appearance
    val themeMode: ThemeMode = ThemeMode.SYSTEM,

    // Behavior
    val autoStartService: Boolean = false,
    val confirmBeforeDelete: Boolean = true,

    // Master button
    val masterButtonHidden: Boolean = false,
    val masterButtonX: Float = 20f,
    val masterButtonY: Float = 600f,

    val onboardingComplete: Boolean = false
)
