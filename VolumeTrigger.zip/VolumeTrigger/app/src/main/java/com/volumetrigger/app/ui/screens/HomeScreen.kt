package com.volumetrigger.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.volumetrigger.app.ui.navigation.AppDestinations
import com.volumetrigger.app.ui.theme.StatusGreen
import com.volumetrigger.app.ui.theme.StatusRed
import com.volumetrigger.app.util.PermissionChecker
import com.volumetrigger.app.viewmodel.AppViewModel

@Composable
fun HomeScreen(viewModel: AppViewModel, onNavigate: (String) -> Unit) {
    val settings by viewModel.settings.collectAsState()
    val serviceRunning by viewModel.serviceRunning.collectAsState()
    val buttons by viewModel.buttons.collectAsState()
    val context = LocalContext.current

    var overlayGranted by remember { mutableStateOf(PermissionChecker.hasOverlayPermission(context)) }
    var accessibilityGranted by remember { mutableStateOf(PermissionChecker.isAccessibilityServiceEnabled(context)) }

    // Re-check permissions every time this screen resumes (e.g. returning
    // from the system Settings screen after granting overlay access).
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                overlayGranted = PermissionChecker.hasOverlayPermission(context)
                accessibilityGranted = PermissionChecker.isAccessibilityServiceEnabled(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Text("Volume Trigger", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Control your floating shortcuts with volume buttons",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(20.dp))

        SectionCard {
            Text("Service Status", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text(
                if (serviceRunning) "ACTIVE" else "INACTIVE",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = if (serviceRunning) StatusGreen else StatusRed
            )
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    when {
                        !overlayGranted -> onNavigate(AppDestinations.PERMISSIONS)
                        serviceRunning -> viewModel.stopService()
                        else -> viewModel.startService()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    when {
                        !overlayGranted -> "Grant overlay permission first"
                        serviceRunning -> "Stop Service"
                        else -> "Start Service"
                    }
                )
            }
        }

        SectionCard {
            StatusRow("Overlay Permission", overlayGranted)
            StatusRow("Accessibility Service", accessibilityGranted)
            StatusRow("Volume Trigger", settings.volumeTriggerEnabled, okText = "ON", badText = "OFF")
            StatusRow(
                "Floating Buttons",
                !settings.masterButtonHidden,
                okText = "Visible",
                badText = "Hidden"
            )
            StatusRow("Configured buttons", buttons.isNotEmpty(), okText = "${buttons.size}", badText = "0")
        }

        Spacer(Modifier.height(8.dp))

        NavCard("Floating Buttons", "Add, move, and manage your shortcuts") {
            onNavigate(AppDestinations.BUTTONS)
        }
        NavCard("Volume Button Trigger", "Assign what Volume Up / Down do") {
            onNavigate(AppDestinations.SETTINGS)
        }
        NavCard("Permissions & Setup", "Overlay and accessibility access") {
            onNavigate(AppDestinations.PERMISSIONS)
        }
        NavCard("Settings", "Appearance, defaults, and behavior") {
            onNavigate(AppDestinations.SETTINGS)
        }

        Spacer(Modifier.height(24.dp))
    }
}
