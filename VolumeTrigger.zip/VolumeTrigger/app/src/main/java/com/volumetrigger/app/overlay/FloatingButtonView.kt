package com.volumetrigger.app.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.isVisible
import com.volumetrigger.app.data.model.ButtonShape
import com.volumetrigger.app.data.model.FloatingButtonConfig
import kotlin.math.abs

/**
 * A single draggable overlay control drawn with WindowManager.addView().
 * Handles its own drag gesture (distinguishing a drag from a tap) and
 * reports the final position back through [onPositionChanged] so it can
 * be persisted. Tap actions are reported through [onClick].
 */
class FloatingButtonView(
    context: Context,
    var config: FloatingButtonConfig,
    private val isMaster: Boolean = false,
    private val onPositionChanged: (id: String, x: Float, y: Float) -> Unit
) : LinearLayout(context) {

    var onClick: (() -> Unit)? = null

    /**
     * Set by OverlayService right after windowManager.addView(this, params).
     * We keep our own reference rather than relying on getLayoutParams(),
     * since that's the pattern every reliable floating-overlay implementation
     * uses to avoid ambiguity about what the base View class returns for a
     * view whose top-level params come from WindowManager, not a parent ViewGroup.
     */
    var windowParams: WindowManager.LayoutParams? = null

    private val icon = ImageView(context)
    private val label = TextView(context)

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var dragging = false
    private val dragThresholdPx = (8 * resources.displayMetrics.density)

    init {
        orientation = VERTICAL
        gravity = android.view.Gravity.CENTER_HORIZONTAL
        addView(icon, LayoutParams(dpToPx(config.sizeDp), dpToPx(config.sizeDp)))
        label.setTextColor(Color.WHITE)
        label.textSize = 11f
        label.gravity = android.view.Gravity.CENTER
        addView(label, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        icon.setPadding(dpToPx(14), dpToPx(14), dpToPx(14), dpToPx(14))
        applyConfig(config)
        setOnTouchListener(::handleTouch)
    }

    private fun applyConfig(cfg: FloatingButtonConfig) {
        icon.setImageResource(IconCatalog.resolve(cfg.icon))
        icon.layoutParams = icon.layoutParams.apply {
            width = dpToPx(cfg.sizeDp); height = dpToPx(cfg.sizeDp)
        }
        val drawable = GradientDrawable().apply {
            setColor(if (isMaster) Color.parseColor("#6750A4") else Color.parseColor("#3B82F6"))
            shape = if (cfg.shape == ButtonShape.ROUNDED_SQUARE) {
                cornerRadius = dpToPx(16).toFloat()
                GradientDrawable.RECTANGLE
            } else {
                GradientDrawable.OVAL
            }
        }
        icon.background = drawable
        icon.alpha = cfg.alphaPercent / 100f
        label.text = cfg.name
        label.isVisible = cfg.showLabel && !isMaster
    }

    fun updateConfig(newConfig: FloatingButtonConfig) {
        config = newConfig
        applyConfig(newConfig)
    }

    fun setHidden(hidden: Boolean) {
        this.isVisible = !hidden
    }

    private fun handleTouch(v: View, event: MotionEvent): Boolean {
        val params = windowParams ?: return false
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = params.x
                initialY = params.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY
                if (!dragging && (abs(dx) > dragThresholdPx || abs(dy) > dragThresholdPx)) {
                    dragging = true
                }
                if (dragging) {
                    params.x = initialX + dx.toInt()
                    params.y = initialY + dy.toInt()
                    runCatching {
                        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                        wm.updateViewLayout(this, params)
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    onPositionChanged(config.id, params.x.toFloat(), params.y.toFloat())
                } else {
                    performClick()
                }
                return true
            }
        }
        return false
    }

    override fun performClick(): Boolean {
        super.performClick()
        onClick?.invoke()
        return true
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()
}
