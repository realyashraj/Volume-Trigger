package com.volumetrigger.app.ui.screens

import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.volumetrigger.app.data.model.ButtonAction
import com.volumetrigger.app.data.model.FloatingButtonConfig

/**
 * Dropdown covering every action listed in the spec. A handful of actions
 * (URL, app, "run another button") need extra input, so they open a small
 * follow-up dialog instead of being picked directly from the menu.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActionPicker(
    label: String,
    currentAction: ButtonAction,
    otherButtons: List<FloatingButtonConfig>,
    onActionSelected: (ButtonAction) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var showUrlDialog by remember { mutableStateOf(false) }
    var showAppDialog by remember { mutableStateOf(false) }
    var showExecuteDialog by remember { mutableStateOf(false) }

    val simpleOptions = listOf(
        ButtonAction.None,
        ButtonAction.GoHome,
        ButtonAction.Back,
        ButtonAction.RecentApps,
        ButtonAction.Notifications,
        ButtonAction.ToggleFloatingButtons,
        ButtonAction.ShowFloatingButtons,
        ButtonAction.HideFloatingButtons,
        ButtonAction.OpenWifiSettings,
        ButtonAction.OpenBluetoothSettings,
        ButtonAction.OpenAppSettings
    )

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = currentAction.displayName(),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            simpleOptions.forEach { action ->
                DropdownMenuItem(text = { Text(action.displayName()) }, onClick = {
                    expanded = false
                    onActionSelected(action)
                })
            }
            DropdownMenuItem(text = { Text("Open a URL…") }, onClick = { expanded = false; showUrlDialog = true })
            DropdownMenuItem(text = { Text("Open an app…") }, onClick = { expanded = false; showAppDialog = true })
            if (otherButtons.isNotEmpty()) {
                DropdownMenuItem(
                    text = { Text("Run another button…") },
                    onClick = { expanded = false; showExecuteDialog = true }
                )
            }
        }
    }

    if (showUrlDialog) {
        UrlInputDialog(
            initial = (currentAction as? ButtonAction.OpenUrl)?.url.orEmpty(),
            onDismiss = { showUrlDialog = false },
            onConfirm = { url -> showUrlDialog = false; onActionSelected(ButtonAction.OpenUrl(url)) }
        )
    }
    if (showAppDialog) {
        AppPickerDialog(
            onDismiss = { showAppDialog = false },
            onSelected = { pkg, appLabel -> showAppDialog = false; onActionSelected(ButtonAction.OpenApp(pkg, appLabel)) }
        )
    }
    if (showExecuteDialog) {
        ExecuteButtonPickerDialog(
            options = otherButtons,
            onDismiss = { showExecuteDialog = false },
            onSelected = { id -> showExecuteDialog = false; onActionSelected(ButtonAction.ExecuteButton(id)) }
        )
    }
}

@Composable
private fun UrlInputDialog(initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Open a URL") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("https://example.com") },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text.trim()) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun AppPickerDialog(onDismiss: () -> Unit, onSelected: (String, String) -> Unit) {
    val context = LocalContext.current
    // Requires the <queries> launcher intent declared in AndroidManifest.xml -
    // without it, package-visibility rules on Android 11+ would hide most apps.
    val apps = remember {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        runCatching {
            pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }
                .sortedBy { it.second.lowercase() }
        }.getOrDefault(emptyList())
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.large, tonalElevation = 4.dp) {
            if (apps.isEmpty()) {
                Box(Modifier.padding(24.dp)) { Text("No launchable apps found.") }
            } else {
                LazyColumn(Modifier.heightIn(max = 480.dp).padding(vertical = 8.dp)) {
                    items(apps) { (pkg, appLabel) ->
                        ListItem(
                            headlineContent = { Text(appLabel) },
                            supportingContent = { Text(pkg, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.clickable { onSelected(pkg, appLabel) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ExecuteButtonPickerDialog(
    options: List<FloatingButtonConfig>,
    onDismiss: () -> Unit,
    onSelected: (String) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.large, tonalElevation = 4.dp) {
            LazyColumn(Modifier.heightIn(max = 400.dp).padding(vertical = 8.dp)) {
                items(options) { button ->
                    ListItem(
                        headlineContent = { Text(button.name) },
                        modifier = Modifier.clickable { onSelected(button.id) }
                    )
                }
            }
        }
    }
}
