package com.volumetrigger.app.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF3B5BDB)
val PurpleSecondary = Color(0xFF6750A4)
val BlueDarkPrimary = Color(0xFFB4C5FF)
val PurpleDarkSecondary = Color(0xFFD0BCFF)
val SurfaceLight = Color(0xFFFAFAFC)
val SurfaceDark = Color(0xFF121218)
val StatusGreen = Color(0xFF16A34A)
val StatusRed = Color(0xFFDC2626)
val StatusAmber = Color(0xFFD97706)
