package com.volumetrigger.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.volumetrigger.app.data.model.ThemeMode
import com.volumetrigger.app.ui.navigation.AppDestinations
import com.volumetrigger.app.ui.screens.AddEditButtonScreen
import com.volumetrigger.app.ui.screens.FloatingButtonsScreen
import com.volumetrigger.app.ui.screens.HomeScreen
import com.volumetrigger.app.ui.screens.OnboardingScreen
import com.volumetrigger.app.ui.screens.PermissionsScreen
import com.volumetrigger.app.ui.screens.SettingsScreen
import com.volumetrigger.app.ui.theme.VolumeTriggerTheme
import com.volumetrigger.app.viewmodel.AppViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settings by viewModel.settings.collectAsState()
            val settingsLoaded by viewModel.settingsLoaded.collectAsState()
            val systemDark = isSystemInDarkTheme()
            val darkTheme = when (settings.themeMode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                ThemeMode.SYSTEM -> systemDark
            }

            VolumeTriggerTheme(darkTheme = darkTheme) {
                if (!settingsLoaded) {
                    // Avoids picking "onboarding" as startDestination for a
                    // split second before the real saved value has loaded -
                    // see the comment on AppViewModel.settingsLoaded.
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {}
                } else {
                    val navController = rememberNavController()
                    val startDestination = if (settings.onboardingComplete) AppDestinations.HOME else AppDestinations.ONBOARDING

                    NavHost(navController = navController, startDestination = startDestination) {

                        composable(AppDestinations.ONBOARDING) {
                            OnboardingScreen(viewModel) {
                                viewModel.updateSettings { it.copy(onboardingComplete = true) }
                                navController.navigate(AppDestinations.HOME) {
                                    popUpTo(AppDestinations.ONBOARDING) { inclusive = true }
                                }
                            }
                        }

                        composable(AppDestinations.HOME) {
                            HomeScreen(viewModel) { route -> navController.navigate(route) }
                        }

                        composable(AppDestinations.BUTTONS) {
                            FloatingButtonsScreen(
                                viewModel = viewModel,
                                onAdd = { navController.navigate(AppDestinations.addEditButtonRoute()) },
                                onEdit = { id -> navController.navigate(AppDestinations.addEditButtonRoute(id)) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            AppDestinations.ADD_EDIT_BUTTON,
                            arguments = listOf(navArgument("id") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")
                            AddEditButtonScreen(
                                viewModel = viewModel,
                                buttonId = if (id == "new") null else id,
                                onDone = { navController.popBackStack() }
                            )
                        }

                        composable(AppDestinations.SETTINGS) {
                            SettingsScreen(viewModel) { navController.popBackStack() }
                        }

                        composable(AppDestinations.PERMISSIONS) {
                            PermissionsScreen(viewModel) { navController.popBackStack() }
                        }
                    }
                }
            }
        }
    }
}
