package com.volumetrigger.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.volumetrigger.app.data.model.FloatingButtonConfig
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.buttonsDataStore by preferencesDataStore(name = "vt_buttons")

/**
 * Persists the list of floating buttons as JSON in DataStore Preferences.
 * Every button gets a stable UUID (see AppViewModel.addButton), so there is
 * no hard limit like "3 buttons" - the list can grow to as many as the
 * user wants.
 *
 * Every mutation below reads the current list AND writes the new one inside
 * a single DataStore.edit {} transaction. That matters here specifically:
 * a button's dragged position is saved by OverlayService the moment the user
 * lets go, and that can happen at the same time the user is adding, editing,
 * or deleting a different button from the app UI. Reading the "current" list
 * outside the transaction (then writing a plain new value back in) would let
 * one of those two writes silently overwrite the other; doing both inside
 * edit {} makes each mutation atomic against every other one.
 */
class ButtonRepository(private val context: Context) {

    private val key = stringPreferencesKey("buttons_json")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val buttonsFlow = context.buttonsDataStore.data.map { prefs -> decode(prefs[key]) }

    private fun decode(raw: String?): List<FloatingButtonConfig> {
        if (raw == null) return emptyList()
        return runCatching { json.decodeFromString<List<FloatingButtonConfig>>(raw) }.getOrDefault(emptyList())
    }

    private suspend fun mutate(transform: (List<FloatingButtonConfig>) -> List<FloatingButtonConfig>) {
        context.buttonsDataStore.edit { prefs ->
            val current = decode(prefs[key])
            prefs[key] = json.encodeToString(transform(current))
        }
    }

    suspend fun addButton(config: FloatingButtonConfig) = mutate { it + config }

    suspend fun updateButton(config: FloatingButtonConfig) = mutate { list ->
        list.map { if (it.id == config.id) config else it }
    }

    suspend fun deleteButton(id: String) = mutate { list -> list.filterNot { it.id == id } }

    suspend fun setEnabled(id: String, enabled: Boolean) = mutate { list ->
        list.map { if (it.id == id) it.copy(enabled = enabled) else it }
    }

    suspend fun reorder(newOrder: List<String>) = mutate { list ->
        val byId = list.associateBy { it.id }
        newOrder.mapNotNull { byId[it] }
    }

    suspend fun updateButtonPosition(id: String, x: Float, y: Float) = mutate { list ->
        list.map { if (it.id == id) it.copy(x = x, y = y) else it }
    }
}
