package com.volumetrigger.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.volumetrigger.app.data.model.ButtonAction

/**
 * Runs a configured ButtonAction. Home/Back/Recents/Notifications go through
 * AccessibilityService.performGlobalAction, which is the only Android API
 * that exposes them to a third-party app - there is no other supported way
 * to trigger these from an app that isn't the default launcher.
 */
object ActionExecutor {

    fun execute(context: Context, action: ButtonAction) {
        when (action) {
            is ButtonAction.None -> Unit
            is ButtonAction.GoHome -> performGlobal(AccessibilityService.GLOBAL_ACTION_HOME)
            is ButtonAction.Back -> performGlobal(AccessibilityService.GLOBAL_ACTION_BACK)
            is ButtonAction.RecentApps -> performGlobal(AccessibilityService.GLOBAL_ACTION_RECENTS)
            is ButtonAction.Notifications -> performGlobal(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            is ButtonAction.ToggleFloatingButtons -> OverlayCommandBus.send(OverlayCommand.ToggleAll)
            is ButtonAction.ShowFloatingButtons -> OverlayCommandBus.send(OverlayCommand.ShowAll)
            is ButtonAction.HideFloatingButtons -> OverlayCommandBus.send(OverlayCommand.HideAll)
            is ButtonAction.ExecuteButton -> OverlayCommandBus.send(OverlayCommand.Execute(action.buttonId))
            is ButtonAction.OpenApp -> launchApp(context, action.packageName)
            is ButtonAction.OpenUrl -> launchUrl(context, action.url)
            is ButtonAction.OpenWifiSettings -> launchSystemSettings(context, Settings.ACTION_WIFI_SETTINGS)
            is ButtonAction.OpenBluetoothSettings -> launchSystemSettings(context, Settings.ACTION_BLUETOOTH_SETTINGS)
            is ButtonAction.OpenAppSettings -> launchSystemSettings(context, Settings.ACTION_SETTINGS)
        }
    }

    private fun performGlobal(globalAction: Int) {
        VolumeAccessibilityService.runningInstance?.performGlobalAction(globalAction)
        // If the service instance isn't available, the accessibility permission
        // isn't really on - the Permissions screen will show this as "Required".
    }

    private fun launchApp(context: Context, packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    private fun launchUrl(context: Context, url: String) {
        val safeUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(safeUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    private fun launchSystemSettings(context: Context, action: String) {
        runCatching { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
